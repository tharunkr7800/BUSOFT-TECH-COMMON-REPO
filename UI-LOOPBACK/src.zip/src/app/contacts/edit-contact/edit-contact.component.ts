import { Component, OnInit,OnDestroy } from '@angular/core';
import { formData } from 'src/app/model/data-model';
import { ContactsService} from './../../services/contacts.service';
import { Subscription } from 'rxjs';
import { Router, ActivatedRoute, ParamMap } from '@angular/router';
@Component({
  selector: 'app-edit-contact',
  templateUrl: './edit-contact.component.html',
  styleUrls: ['./edit-contact.component.scss']
})
export class EditContactComponent implements OnInit {
  formDataSubscription:Subscription;
  formData?:formData;
  contacttReference:string;
  constructor(private contactsService:ContactsService,private _router:ActivatedRoute) {
    this.formDataSubscription = new Subscription();
    this.formData = undefined;
    this.contacttReference ='';
  }
  getFormData(){
    return this.contactsService.getContactInfo();
  }

  ngOnInit() {
    this.formDataSubscription = this.getFormData().subscribe(res => {
      this.formData = res;
      console.log(this.formData);
    });
    this._router.queryParams.subscribe(data => {
      if(data['incidentInfo']){
        let incidentInfo = JSON.parse(data['incidentInfo']);
        console.log("incidentINfo",incidentInfo);
        this.contacttReference = incidentInfo.lastname + " " + incidentInfo.firstname;
      }
    })
  }
 ngOnDestroy(){
   this.formDataSubscription.unsubscribe();
 }
}
