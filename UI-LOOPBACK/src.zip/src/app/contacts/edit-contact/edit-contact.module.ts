import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { EditContactRoutingModule } from './edit-contact-routing.module';
import {EditContactComponent} from './edit-contact.component';
import { SharedModule } from 'src/app/shared/shared.module';
@NgModule({
  declarations: [EditContactComponent],
  imports: [
    CommonModule,
    EditContactRoutingModule,
    SharedModule
  ]
})
export class EditContactModule { }
