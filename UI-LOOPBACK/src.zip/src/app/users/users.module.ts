import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { UsersRoutingModule } from './users-routing.module';
import { UsersComponent } from './users.component';
import {InputTextModule} from 'primeng/inputtext';
import {AutoCompleteModule} from 'primeng/autocomplete';
import { TableModule } from 'primeng/table';
import {FileUploadModule} from 'primeng/fileupload';
import {HttpClientModule} from '@angular/common/http';
import {PasswordModule} from 'primeng/password';
@NgModule({
  declarations: [
    UsersComponent
  ],
  imports: [
    CommonModule,
    UsersRoutingModule,
    InputTextModule,
    AutoCompleteModule,
    TableModule,
    FileUploadModule,
    HttpClientModule,
    PasswordModule
  ]
})
export class UsersModule { }
