import { Component, OnInit } from '@angular/core';
import { NavigationExtras, Router } from '@angular/router';
interface dlist {
  label: string,
  value: string
};
interface userInfo{
  firstname:string;
  lastname:string;
  profile:string;
  status:string;
  email:string;
  phone:string;
}
@Component({
  selector: 'app-users',
  templateUrl: './users.component.html',
  styleUrls: ['./users.component.scss']
})

export class UsersComponent implements OnInit {
  userInfoData:Array<userInfo>;
  constructor(private _router:Router) {
    this.userInfoData = [
      {firstname:"user 1",lastname:"user 12",profile:"Agent",status:"active",email:"user1@test.com",phone:"99999999"},
      {firstname:"user 2",lastname:"user 22",profile:"Manager",status:"active",email:"user2@test.com",phone:"99999999"},
      {firstname:"user 3",lastname:"user 32",profile:"Agent",status:"Inactive",email:"user3@test.com",phone:"99999999"},
      {firstname:"user 4",lastname:"user 42",profile:"Agent",status:"active",email:"user4@test.com",phone:"99999999"},
    ]
  }

  ngOnInit(): void {
  }
  onSelect(data:userInfo){
    const params : NavigationExtras = {
      queryParams:{
        incidentInfo: JSON.stringify(data)
      },
      skipLocationChange:false
    }
    this._router.navigate(["/newAgents"],params);
  }
}
