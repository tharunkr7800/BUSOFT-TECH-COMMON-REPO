import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { EditUserRoutingModule } from './edit-user-routing.module';


@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    EditUserRoutingModule
  ]
})
export class EditUserModule { }
